package com.rohan.clips

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface

class MainActivity : Activity() {
    private val dark = Color.rgb(23, 23, 23)
    private val purple = Color.rgb(91, 91, 214)
    private var selectedVideo: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showSplash()
    }

    private fun showSplash() {
        val splash = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundColor(dark)
        }
        val title = TextView(this).apply {
            text = "✂  Clips by Rohan"
            textSize = 30f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        val credit = TextView(this).apply {
            text = "Developed by Rohan in partnership with CHAT gpt"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 0)
        }
        splash.addView(title)
        splash.addView(credit)
        setContentView(splash)
        splash.postDelayed({ showHome() }, 2200)
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 36, 24, 24)
            setBackgroundColor(Color.rgb(248, 248, 250))
        }
        val heading = TextView(this).apply {
            text = "Clips by Rohan"
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(dark)
        }
        val intro = TextView(this).apply {
            text = "Turn long videos into short clips. Your creative workspace starts here."
            textSize = 16f
            setTextColor(Color.DKGRAY)
            setPadding(0, 12, 0, 24)
        }
        val choose = Button(this).apply {
            text = "Choose a video"
            setOnClickListener { chooseVideo() }
        }
        val status = TextView(this).apply {
            id = View.generateViewId()
            text = "No video selected"
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(0, 18, 0, 18)
        }
        val note = TextView(this).apply {
            text = "Starter version\nVideo selection is available. AI moment detection, automatic captions, trimming and exporting are still being developed."
            textSize = 14f
            setTextColor(Color.GRAY)
            setPadding(0, 28, 0, 0)
        }
        root.addView(heading)
        root.addView(intro)
        root.addView(choose)
        root.addView(status)
        root.addView(note)
        setContentView(root)
    }

    private fun chooseVideo() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
        }
        startActivityForResult(intent, 1001)
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == RESULT_OK) {
            selectedVideo = data?.data
            val name = selectedVideo?.lastPathSegment ?: "Video selected"
            val label = findViewById<TextView?>(-1)
            // Rebuild the screen with the selected video information.
            showHomeWithSelection(name)
        }
    }

    private fun showHomeWithSelection(name: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 36, 24, 24)
            setBackgroundColor(Color.rgb(248, 248, 250))
        }
        root.addView(TextView(this).apply {
            text = "Clips by Rohan"; textSize = 28f
            typeface = Typeface.DEFAULT_BOLD; setTextColor(dark)
        })
        root.addView(TextView(this).apply {
            text = "Selected video: $name"; textSize = 15f
            setTextColor(Color.DKGRAY); setPadding(0, 24, 0, 24)
        })
        root.addView(Button(this).apply {
            text = "Choose another video"
            setOnClickListener { chooseVideo() }
        })
        root.addView(TextView(this).apply {
            text = "AI clipping, captions and export are coming in a later development stage."
            textSize = 14f; setTextColor(Color.GRAY); setPadding(0, 28, 0, 0)
        })
        setContentView(root)
    }
}
